﻿using System;
namespace Sorting_Numbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int A = 3;
            int B = 6;
            int C = 16;
            int D = 8;

            int x = 4;
            int[] Arraya = new int[x];
            Arraya[0] = A;
            Arraya[1] = B;
            Arraya[2] = C;
            Arraya[3] = D;

            int num = 0;

            for (int i = 0; i < x; i++)
            {
                if (i + 1 > x - 1)
                {
                    Console.ReadKey();
                    return;
                }
                else
                {
                    if (Arraya[i] < Arraya[i + 1])
                    {
                        num = Arraya[i];
                        Console.WriteLine(num);
                    }

                    else
                    {
                        num = Arraya[i + 1];
                        Console.WriteLine(num);
                        Console.WriteLine(Arraya[i]);
                    }
                }
            }
        }
    }
}